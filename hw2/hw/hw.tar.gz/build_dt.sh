#!/bin/sh

/opt/python-3.6/bin/python3.6 build_tree.py $1 $2 $3 $4 $5 $6
